hi = 'hello'
print(hi)
